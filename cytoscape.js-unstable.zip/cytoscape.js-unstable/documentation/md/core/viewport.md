## Examples

```js
cy.viewport({
  zoom: 2,
  pan: { x: 100, y: 100 }
});
```