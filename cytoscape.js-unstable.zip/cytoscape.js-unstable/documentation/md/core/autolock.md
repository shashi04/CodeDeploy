## Examples

Enable:
```js
cy.autolock( true );
```

Disable:
```js
cy.autolock( false );
```