## Details

If the core instance is headless prior to calling `cy.mount()`, then the instance will no longer be headless and the visualisation will be shown in the specified container.  If the core instance is non-headless prior to calling `cy.mount()`, then the visualisation is swapped from the prior container to the specified container.