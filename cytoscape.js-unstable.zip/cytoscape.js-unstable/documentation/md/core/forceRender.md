## Details

This function forces the renderer to draw a new frame.  It is useful for very specific edgecases, such as in certain UI extensions, but it should not be needed for most developers.
