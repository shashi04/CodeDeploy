## Examples

Enable:
```js
cy.userZoomingEnabled( true );
```

Disable:
```js
cy.userZoomingEnabled( false );
```