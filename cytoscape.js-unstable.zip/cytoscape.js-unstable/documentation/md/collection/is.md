## Examples

```js
var j = cy.$('#j');

console.log( 'j has weight > 50 ? ' + j.is('[weight > 50]') );
```