## Examples

```js
cy.$('#j').panify();
```