## Examples

```js
cy.$('#j').unselect();
```