## Examples

```js
var je = cy.$('#je');

je.target();
```