## Examples

```js
cy.$('#j').selectify();
```
