## Examples

```js
var j = cy.$('#j');
var gAndK = cy.$('#g, #k');

console.log( 'all neighbours ? ' + j.allAreNeighbors(gAndK) );
```