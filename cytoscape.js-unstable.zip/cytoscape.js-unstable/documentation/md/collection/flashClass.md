## Examples

```js
cy.$('#j, #e').flashClass('foo', 1000);
```