# Security Policy

## Reporting a Vulnerability

Please report security issues to maxkfranz@gmail.com. Thank you.
